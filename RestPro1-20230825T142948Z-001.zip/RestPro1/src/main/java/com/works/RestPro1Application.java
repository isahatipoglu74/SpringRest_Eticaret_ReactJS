package com.works;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestPro1Application {

    public static void main(String[] args) {
        SpringApplication.run(RestPro1Application.class, args);
    }

}
