package com.works.entities.projections;

public interface IProCat {

    Long getid();
    String getbrandname();
    String getdescription();
    String gettitle();
    Long getprice();
    Long getstock();
    String getthumbnail();
    Long getcid();

}